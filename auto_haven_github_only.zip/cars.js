// AUTO HAVEN INVENTORY
// Add a car by copying one object below, pasting it inside CARS, and changing its details.
// Put a comma between car objects. Give every car a unique id.

const STORE = {
  phoneDisplay: "(604) 555-0123", // Replace with your real phone number
  email: "info@autohaven.ca",     // Replace with your real email
  location: "Surrey, BC"
};

const CARS = [
  {
    id: "car-001",
    year: 2021,
    make: "Toyota",
    model: "Camry",
    trim: "SE Sedan",
    price: 24999,
    km: 58200,
    transmission: "Automatic",
    fuel: "Gasoline",
    location: "Surrey, BC",
    badge: "FEATURED",
    status: "available",
    image: "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?auto=format&fit=crop&w=1000&q=85",
    description: "Comfortable sedan. Contact Auto Haven for more information or to arrange a viewing."
  },
  {
    id: "car-002",
    year: 2020,
    make: "Honda",
    model: "Civic",
    trim: "Sport Sedan",
    price: 21999,
    km: 64500,
    transmission: "Automatic",
    fuel: "Gasoline",
    location: "Surrey, BC",
    badge: "POPULAR",
    status: "available",
    image: "https://images.unsplash.com/photo-1606152421802-db97b9c7a11b?auto=format&fit=crop&w=1000&q=85",
    description: "Sporty daily driver. Contact us to confirm availability and details."
  }
];
