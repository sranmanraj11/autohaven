AUTO HAVEN — GITHUB ONLY

UPLOAD:
1. Open your GitHub repository called CARHAVEN.
2. Click Add file > Upload files.
3. Upload index.html and cars.js.
4. Click Commit changes.
5. Open Settings > Pages.
6. Choose Deploy from a branch, branch main, folder /(root), then Save.
7. Wait for GitHub Pages to publish your website. The URL appears in Settings > Pages.

ADD A CAR:
1. Open cars.js in GitHub and click the pencil icon.
2. Copy one full car object inside the CARS list.
3. Paste it after the existing car, adding a comma between objects.
4. Change the id, year, make, model, price, km, image and description.
5. Click Commit changes.

IMPORTANT:
Replace sample phone, email and vehicles before publishing. Use photos you own or have permission to use.
GitHub Pages is static hosting. It cannot provide a secure private admin dashboard or database. You manage inventory by editing cars.js in GitHub. Email links work for inquiries; a real online form needs an external form service or backend. Financing copy is general information, not a financing offer.
